'use client';

import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Store, Trash2, Loader2, AlertCircle, PackageOpen, Phone, MapPin, PackagePlus } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import AddProductModal from '@/components/modals/AddProductModal';

interface ManageShopsModalProps {
  onClose: () => void;
}

interface ProductMedia {
  id: string;
  file_url: string;
}

interface Product {
  id: string;
  title: string;
  price: number | null;
  product_media: ProductMedia[];
}

interface Shop {
  id: string;
  business_name: string;
  phone: string;
  address: string | null;
  category_title: string;
  products: Product[];
}

export const ManageShopsModal: React.FC<ManageShopsModalProps> = ({ onClose }) => {
  const { user } = useAuth();
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null); // id currently being deleted (shop or product)
  const [addProductTarget, setAddProductTarget] = useState<{ shopId: string; businessName: string } | null>(null);

  const fetchMyShops = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('shops')
      .select(
        `
        id, business_name, phone, address, category_title,
        products (
          id, title, price,
          product_media ( id, file_url )
        )
      `
      )
      .eq('owner_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(error);
      setErrorMsg('Could not load your shops. Please try again.');
    } else {
      setShops((data as unknown as Shop[]) ?? []);
      setErrorMsg(null);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMyShops();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Removes every file stored under a given "folder" (a product id) in the bucket.
  const removeStorageFolder = async (productId: string) => {
    const { data: files, error: listError } = await supabase.storage.from('product-media').list(productId);
    if (listError || !files || files.length === 0) return;
    const paths = files.map((f) => `${productId}/${f.name}`);
    await supabase.storage.from('product-media').remove(paths);
  };

  const handleDeleteProduct = async (product: Product, shopId: string) => {
    if (!confirm(`Delete "${product.title}"? This cannot be undone.`)) return;
    setBusyId(product.id);
    setErrorMsg(null);
    try {
      await removeStorageFolder(product.id);
      const { error } = await supabase.from('products').delete().eq('id', product.id);
      if (error) throw error;

      setShops((prev) =>
        prev.map((s) => (s.id === shopId ? { ...s, products: s.products.filter((p) => p.id !== product.id) } : s))
      );
    } catch (err) {
      console.error(err);
      setErrorMsg(err instanceof Error ? err.message : 'Could not delete that product.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDeleteShop = async (shop: Shop) => {
    if (
      !confirm(
        `Delete "${shop.business_name}" and all ${shop.products.length} product(s) under it? This cannot be undone.`
      )
    )
      return;
    setBusyId(shop.id);
    setErrorMsg(null);
    try {
      // Clean up storage for every product under this shop first.
      for (const product of shop.products) {
        await removeStorageFolder(product.id);
      }
      const { error } = await supabase.from('shops').delete().eq('id', shop.id);
      if (error) throw error;

      setShops((prev) => prev.filter((s) => s.id !== shop.id));
    } catch (err) {
      console.error(err);
      setErrorMsg(err instanceof Error ? err.message : 'Could not delete that shop.');
    } finally {
      setBusyId(null);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2 text-white font-bold text-base">
            <Store className="w-5 h-5 text-emerald-400" />
            <span>My Shops</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          {errorMsg && (
            <div className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {loading && (
            <div className="text-center py-14">
              <Loader2 className="w-8 h-8 text-emerald-400 mx-auto mb-3 animate-spin" />
              <p className="text-xs text-slate-400">Loading your shops...</p>
            </div>
          )}

          {!loading && shops.length === 0 && (
            <div className="text-center py-14">
              <Store className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">No shops yet</h3>
              <p className="text-xs text-slate-400">Create a shop from any category to see it here.</p>
            </div>
          )}

          {!loading && shops.length > 0 && (
            <div className="space-y-5">
              {shops.map((shop) => (
                <div key={shop.id} className="rounded-xl border border-slate-800 bg-slate-950/50 p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className="inline-block mb-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border border-emerald-500/30 bg-emerald-500/10 text-emerald-300">
                        {shop.category_title}
                      </span>
                      <h3 className="font-bold text-white text-sm">{shop.business_name}</h3>
                      <div className="flex flex-wrap items-center gap-3 mt-1 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          <span>{shop.phone}</span>
                        </span>
                        {shop.address && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{shop.address}</span>
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <button
                        onClick={() => setAddProductTarget({ shopId: shop.id, businessName: shop.business_name })}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-[11px] font-medium whitespace-nowrap"
                      >
                        <PackagePlus className="w-3.5 h-3.5" />
                        <span>Add Product</span>
                      </button>
                      <button
                        onClick={() => handleDeleteShop(shop)}
                        disabled={busyId === shop.id}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 text-[11px] font-medium disabled:opacity-50 whitespace-nowrap"
                      >
                        {busyId === shop.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                        <span>Delete Shop</span>
                      </button>
                    </div>
                  </div>

                  {shop.products.length === 0 ? (
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-3">
                      <PackageOpen className="w-3.5 h-3.5" />
                      <span>No products listed yet</span>
                    </div>
                  ) : (
                    <div className="space-y-2 mt-3">
                      {shop.products.map((product) => (
                        <div
                          key={product.id}
                          className="flex items-center justify-between gap-2 border-t border-slate-800/70 pt-2"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {product.product_media[0] && (
                              <img
                                src={product.product_media[0].file_url}
                                alt=""
                                className="w-8 h-8 rounded-md object-cover flex-shrink-0 bg-slate-900"
                              />
                            )}
                            <div className="min-w-0">
                              <p className="text-xs text-white truncate">{product.title}</p>
                              {product.price !== null && (
                                <p className="text-[11px] text-emerald-400">₦{Number(product.price).toLocaleString()}</p>
                              )}
                            </div>
                          </div>
                          <button
                            onClick={() => handleDeleteProduct(product, shop.id)}
                            disabled={busyId === product.id}
                            className="flex items-center gap-1 px-2 py-1 rounded-md bg-slate-800 hover:bg-red-500/20 hover:text-red-300 text-slate-300 text-[10px] font-medium disabled:opacity-50 whitespace-nowrap"
                          >
                            {busyId === product.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                            <span>Remove</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {addProductTarget && (
        <AddProductModal
          shopId={addProductTarget.shopId}
          businessName={addProductTarget.businessName}
          onClose={() => setAddProductTarget(null)}
          onProductAdded={fetchMyShops}
        />
      )}
    </div>,
    document.body
  );
};

export default ManageShopsModal;
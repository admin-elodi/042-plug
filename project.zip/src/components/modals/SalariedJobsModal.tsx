'use client';

import React, { useState } from 'react';
import { X, Briefcase, Building2, MapPin, DollarSign, Phone, FileText, Send, Clock } from 'lucide-react';

interface SalariedJobsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SalariedJobsModal: React.FC<SalariedJobsModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    jobTitle: '',
    companyName: '',
    location: '',
    jobType: 'Full-time',
    salary: '',
    contactPhone: '',
    description: '',
  });

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleWhatsAppSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Formatted detailed message for WhatsApp submission
    const message = 
` Hello 042 Plug! 💼

I would like to submit a new job vacancy for review and listing:

📌 *Job Title:* ${formData.jobTitle}
🏢 *Company / Business:* ${formData.companyName}
📍 *Location:* ${formData.location}
⏱️ *Job Type:* ${formData.jobType}
💰 *Salary / Compensation:* ${formData.salary ? formData.salary : 'Negotiable / Undisclosed'}
📞 *Contact Phone:* ${formData.contactPhone}

📝 *Job Details & Requirements:*
${formData.description}

---
Please let me know once this has been reviewed and published on the platform!`;

    const encodedMessage = encodeURIComponent(message);
    // Replace with your designated admin WhatsApp number if different
    const whatsappUrl = `https://wa.me/2348136573235?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-2xl bg-stone-900 border border-stone-800 p-6 shadow-2xl text-stone-100 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Briefcase className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Post a Vacancy</h2>
            <p className="text-xs text-stone-400">Submit job details for review and publication</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleWhatsAppSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Job Title *
            </label>
            <div className="relative">
              <Briefcase className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
              <input
                type="text"
                name="jobTitle"
                required
                placeholder="e.g. Graphic Designer, Store Assistant"
                value={formData.jobTitle}
                onChange={handleChange}
                className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Company / Employer Name *
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
                <input
                  type="text"
                  name="companyName"
                  required
                  placeholder="e.g. Enugu Tech Hub"
                  value={formData.companyName}
                  onChange={handleChange}
                  className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Location *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
                <input
                  type="text"
                  name="location"
                  required
                  placeholder="e.g. Independence Layout, Enugu"
                  value={formData.location}
                  onChange={handleChange}
                  className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Job Type
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 absolute left-3 top-3 text-stone-500 pointer-events-none" />
                <select
                  name="jobType"
                  value={formData.jobType}
                  onChange={handleChange}
                  className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 transition-colors appearance-none cursor-pointer"
                >
                  <option value="Full-time">Full-time</option>
                  <option value="Part-time">Part-time</option>
                  <option value="Contract">Contract</option>
                  <option value="Internship">Internship</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Salary / Pay (Optional)
              </label>
              <div className="relative">
                <DollarSign className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
                <input
                  type="text"
                  name="salary"
                  placeholder="e.g. ₦80,000 / month"
                  value={formData.salary}
                  onChange={handleChange}
                  className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Contact Phone / WhatsApp *
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
              <input
                type="tel"
                name="contactPhone"
                required
                placeholder="e.g. 08012345678"
                value={formData.contactPhone}
                onChange={handleChange}
                className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Job Description & Qualifications *
            </label>
            <div className="relative">
              <FileText className="w-4 h-4 absolute left-3 top-3 text-stone-500" />
              <textarea
                name="description"
                required
                rows={4}
                placeholder="Provide details about the role, responsibilities, requirements, and how to apply..."
                value={formData.description}
                onChange={handleChange}
                className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:border-amber-500 transition-colors resize-none"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors shadow-lg shadow-amber-500/10"
            >
              <Send className="w-4 h-4" />
              <span>Post Job</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SalariedJobsModal;